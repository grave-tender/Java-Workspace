
package examenalgofinal;

public class ExamenAlgoFinal {
    public static void main(String[] args) {
        Exercice1.minEntre2Valeurs();
        Exercice2.minEntre3Valeurs();
        Exercice3.additionsBondsDe2();
        Exercice4.calculModulo();
        Exercice5.sommeTableau();
        Exercice6.compteurMadrid();
    }
}
